//
//  IBPEventItem.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * This is an abstract class it shouldn't be initiated.
 */
@interface IBPEventItem : NSObject

@end
