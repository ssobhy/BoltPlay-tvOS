//
//  IBPEvent.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import <Foundation/Foundation.h>
#import "IBPEventItem.h"

@interface IBPEvent : NSObject

@property (readonly) NSString *eventType;
@property (readonly) NSString *eventError;
@property (readonly) IBPEventItem *eventItem;

- (instancetype)initWithEventType:(NSString *)eventType eventError:(NSString *)eventError eventItem:(IBPEventItem *)eventItem;

@end
