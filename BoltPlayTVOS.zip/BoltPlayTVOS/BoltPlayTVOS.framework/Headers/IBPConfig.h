//
//  IBPConfig.h
//  BoltPlay
//
//  Created by Ahmed Hafez on 1/8/17.
//  Copyright © 2017 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IBPConfigBuilder : NSObject

@property(nonatomic) NSInteger storageLimit;
@property(nonatomic) NSInteger batteryLevel;
@property(nonatomic) NSDictionary* logsExtras;
@end

@interface IBPConfig : NSObject

+ (instancetype) boltPlayConfigWithBlock:(void (^)(IBPConfigBuilder *))updateBlock;

- (void)commit;

+ (NSInteger)getStorageLimit;

+ (NSInteger)getBatteryLimit;

@end
